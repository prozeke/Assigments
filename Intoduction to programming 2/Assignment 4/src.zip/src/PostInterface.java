import java.util.Date;

public interface PostInterface {
	public void setText(String text);
	public String getText();
	public Date getDate();
	
}
